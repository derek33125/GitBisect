# Case 3

`known_good` prints this translation unit. `known_bad` hits an unreachable while printing it.

`bounds.json` gives both commits. Read `crash-report.md` and `reproducer.cpp`.

Find the first bad commit in `(known_good, known_bad]`.
