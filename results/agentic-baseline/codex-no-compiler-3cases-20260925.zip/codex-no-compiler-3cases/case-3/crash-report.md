# Crash report

`clang -cc1 -ast-print` crashes on the reproducer.

```
clang -cc1 -ast-print -xc++ reproducer.cpp
```

Diagnostic:

```
unexpected specialization kind
UNREACHABLE executed at clang/lib/AST/DeclPrinter.cpp
Stack dump:
0.  Program arguments: clang -cc1 -ast-print -xc++ -
1.  <eof> parser at end of file
```

Meaningful frames:

- `DeclPrinter::VisitExplicitInstantiationDecl`
- `DeclPrinter::VisitDeclContext`
- `DeclPrinter::VisitTranslationUnitDecl`
- `clang::Decl::print`
- `ASTPrinter::print`
- `ASTPrinter::HandleTranslationUnit`
- `clang::ParseAST`
