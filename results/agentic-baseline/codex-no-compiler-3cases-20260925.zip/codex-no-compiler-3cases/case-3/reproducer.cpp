struct Struct1 {};
template <typename T> T bar = T{};

extern template Struct1 bar<Struct1>;
