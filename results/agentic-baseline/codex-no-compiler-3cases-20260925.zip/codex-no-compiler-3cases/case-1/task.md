# Case 1

Clang 21 accepts the reproducer. `known_bad` crashes on it.

`bounds.json` gives both commits. Read `crash-report.md` and `reproducer.cpp`.

Find the first bad commit in `(known_good, known_bad]`.
