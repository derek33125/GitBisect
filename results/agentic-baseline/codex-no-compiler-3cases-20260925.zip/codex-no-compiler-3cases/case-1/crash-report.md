# Crash report

The reproducer compiles on Clang 21 and GCC. On a later Clang trunk it crashes while compiling `foo`.

Command that hits the crash:

```
clang++ -std=c++20 -O3 -c reproducer.cpp
```

Frontend diagnostic:

```
reproducer.cpp:30:12: error: cannot compile this l-value expression yet
   30 |     return bar<Alias<A.size(), A>>();
      |            ^~~~~~~~~~~~~~~~~~~~~~~
Stack dump:
1.	<eof> parser at end of file
2.	Per-file LLVM IR generation
3.	reproducer.cpp:28:15: Generating code for declaration 'foo'
clang++: error: clang frontend command failed with exit code 139
```

An assertions build reports:

```
Unexpected placeholder builtin type!
UNREACHABLE executed at clang/lib/CodeGen/CodeGenTypes.cpp
```

Meaningful frames:

- `clang::CodeGen::CodeGenTypes::ConvertType(clang::QualType)`
- `clang::CodeGen::CodeGenFunction::EmitUnsupportedLValue`
- `clang::CodeGen::CodeGenFunction::EmitLValue`
- `clang::CodeGen::CodeGenFunction::EmitCallee`
- `clang::CodeGen::CodeGenFunction::EmitCallExpr`
- generating code for the declaration `foo`
