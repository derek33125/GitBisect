#include <array>
#include <cstddef>
#include <tuple>
#include <utility>

template <int V>
struct Tag {};

template <class... Ts>
struct Wrapper {
    constexpr Wrapper(std::tuple<Ts...>) {}
};

template <size_t N, std::array<int, N> A>
consteval auto make_tuple() {
    return []<size_t... I>(std::index_sequence<I...>) {
        return std::tuple<Tag<A[I]>...>{};
    }(std::make_index_sequence<N>{});
}

template <size_t N, std::array<int, N> A>
using Alias = decltype(Wrapper{ make_tuple<N, A>() });

template <class>
constexpr int bar() { return 1; }

template <std::array A>
constexpr int foo() {
    // "error: cannot compile this l-value expression yet":
    return bar<Alias<A.size(), A>>();
}

int main() {
    constexpr std::array data = {1};
    return foo<data>();
}
