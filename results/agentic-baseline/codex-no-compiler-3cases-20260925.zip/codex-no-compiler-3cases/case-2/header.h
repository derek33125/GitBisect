#pragma once

inline namespace {
template<typename T> T g(T v) { return v; }
template<typename T> T f(T v) { return g(v); }
template<typename T> T g();
}
