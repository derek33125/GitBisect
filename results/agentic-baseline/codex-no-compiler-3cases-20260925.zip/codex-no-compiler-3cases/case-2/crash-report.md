# Crash report

Building a precompiled header from `header.h`, then compiling `main.cpp` with `-ftime-trace` and that PCH, crashes an assertions Clang.

```
clang -x c++-header -c header.h -o pch.pch
clang -ftime-trace -c main.cpp -include-pch pch.pch
```

The crashing compiler identifies itself as:

```
clang version 22.0.0git 93ebe63f2e7a252038bde01a4399c14e0123cdac
Build config: +assertions
```

Diagnostic:

```
Assertion failed: (isHandleInSync() && "invalid iterator access!"), function operator*, file DenseMap.h, line 1211.
Stack dump:
1.  <eof> parser at end of file
2.  header.h:5:25: instantiating function definition 'f<int>'
clang: error: clang frontend command failed with exit code 134
```

Meaningful frames:

- `clang::serialization::MultiOnDiskHashTable<LazySpecializationInfoLookupTrait>::find`
- `clang::ASTReader::LoadExternalSpecializationsImpl`
- `clang::ASTReader::LoadExternalSpecializations`
- `clang::FunctionTemplateDecl::findSpecialization`
- `clang::TemplateDeclInstantiator::VisitFunctionDecl`
- `clang::Sema::SubstDecl`
- `clang::Sema::FinishTemplateArgumentDeduction`
- `clang::Sema::DeduceTemplateArguments`
- `clang::Sema::BuildOverloadedCallExpr`
- `clang::Sema::InstantiateFunctionDefinition`
