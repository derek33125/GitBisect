# Case 2

`known_good` accepts the two-file reproducer. `known_bad` crashes on it. The crashing compiler revision is the `known_bad` value in `bounds.json`.

Read `crash-report.md`, `header.h`, and `main.cpp`.

Find the first bad commit in `(known_good, known_bad]`.
