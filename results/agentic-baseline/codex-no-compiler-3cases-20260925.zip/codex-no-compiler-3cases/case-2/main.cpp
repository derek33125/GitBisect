#include "header.h"

int x;
void i() { f(x); }
