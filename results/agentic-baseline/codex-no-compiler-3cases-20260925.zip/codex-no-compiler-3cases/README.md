# Agentic bisect packet

Find the first bad commit for each case. A first bad commit is the earliest commit in `(known_good, known_bad]` that introduces the crash in the reproducer.

## Environment

Use a normal `llvm-project` git checkout. `known_good` and `known_bad` are full commit ids in that history. `known_good` is an ancestor of `known_bad`.

This run does not have a compiler. Do not configure, build, or run clang, cmake, ninja, or Compiler Explorer. Do not ask for compiler permission.

Do not browse the web, GitHub issues, pull requests, commit searches, or mail archives for these crashes. The files in each case directory are the whole bug report. The checkout's own history, diffs, and source are allowed.

## What to return

For each case, write:

- the full 40-character commit id
- the commit subject
- a short reason grounded in the crash report and the change

Do not build the compiler to check the answer.
